---
# No checklists needed - this task facilitates brainstorming sessions, validation is through user interaction
docOutputLocation: docs/brainstorming-session-results.md
template: ".aios-core/product/templates/brainstorming-output-tmpl.yaml"
tools:
  - github-cli
---

# Facilitate Brainstorming Session Task

Facilitate interactive brainstorming sessions with users. Be creative and adaptive in applying techniques.

## Execution Modes

**Choose your execution mode:**

### 1. YOLO Mode - Fast, Autonomous (0-1 prompts)
- Autonomous decision making with logging
- Minimal user interaction
- **Best for:** Simple, deterministic tasks

### 2. Interactive Mode - Balanced, Educational (5-10 prompts) **[DEFAULT]**
- Explicit decision checkpoints
- Educational explanations
- **Best for:** Learning, complex decisions

### 3. Pre-Flight Planning - Comprehensive Upfront Planning
- Task analysis phase (identify all ambiguities)
- Zero ambiguity execution
- **Best for:** Ambiguous requirements, critical work

**Parameter:** `mode` (optional, default: `interactive`)

---

## Task Definition (AIOS Task Format V1.0)

```yaml
task: analystFacilitateBrainstorming()
responsável: Atlas (Decoder)
responsavel_type: Agente
atomic_layer: Strategy

**Entrada:**
- campo: task
  tipo: string
  origem: User Input
  obrigatório: true
  validação: Must be registered task

- campo: parameters
  tipo: object
  origem: User Input
  obrigatório: false
  validação: Valid task parameters

- campo: mode
  tipo: string
  origem: User Input
  obrigatório: false
  validação: yolo|interactive|pre-flight

**Saída:**
- campo: execution_result
  tipo: object
  destino: Memory
  persistido: false

- campo: logs
  tipo: array
  destino: File (.ai/logs/*)
  persistido: true

- campo: state
  tipo: object
  destino: State management
  persistido: true
```

---

## Pre-Conditions

**Purpose:** Validate prerequisites BEFORE task execution (blocking)

**Checklist:**

```yaml
pre-conditions:
  - [ ] Task is registered; required parameters provided; dependencies met
    tipo: pre-condition
    blocker: true
    validação: |
      Check task is registered; required parameters provided; dependencies met
    error_message: "Pre-condition failed: Task is registered; required parameters provided; dependencies met"
```

---

## Post-Conditions

**Purpose:** Validate execution success AFTER task completes

**Checklist:**

```yaml
post-conditions:
  - [ ] Task completed; exit code 0; expected outputs created
    tipo: post-condition
    blocker: true
    validação: |
      Verify task completed; exit code 0; expected outputs created
    error_message: "Post-condition failed: Task completed; exit code 0; expected outputs created"
```

---

## Acceptance Criteria

**Purpose:** Definitive pass/fail criteria for task completion

**Checklist:**

```yaml
acceptance-criteria:
  - [ ] Task completed as expected; side effects documented
    tipo: acceptance-criterion
    blocker: true
    validação: |
      Assert task completed as expected; side effects documented
    error_message: "Acceptance criterion not met: Task completed as expected; side effects documented"
```

---

## Tools

**External/shared resources used by this task:**

- **Tool:** task-runner
  - **Purpose:** Task execution and orchestration
  - **Source:** .aios-core/core/task-runner.js

- **Tool:** logger
  - **Purpose:** Execution logging and error tracking
  - **Source:** .aios-core/utils/logger.js

---

## Scripts

**Agent-specific code for this task:**

- **Script:** execute-task.js
  - **Purpose:** Generic task execution wrapper
  - **Language:** JavaScript
  - **Location:** .aios-core/scripts/execute-task.js

---

## Error Handling

**Strategy:** retry

**Common Errors:**

1. **Error:** Task Not Found
   - **Cause:** Specified task not registered in system
   - **Resolution:** Verify task name and registration
   - **Recovery:** List available tasks, suggest similar

2. **Error:** Invalid Parameters
   - **Cause:** Task parameters do not match expected schema
   - **Resolution:** Validate parameters against task definition
   - **Recovery:** Provide parameter template, reject execution

3. **Error:** Execution Timeout
   - **Cause:** Task exceeds maximum execution time
   - **Resolution:** Optimize task or increase timeout
   - **Recovery:** Kill task, cleanup resources, log state

---

## Performance

**Expected Metrics:**

```yaml
duration_expected: 5-20 min (estimated)
cost_estimated: $0.003-0.015
token_usage: ~2,000-8,000 tokens
```

**Optimization Notes:**
- Iterative analysis with depth limits; cache intermediate results; batch similar operations

---

## Metadata

```yaml
story: N/A
version: 1.0.0
dependencies:
  - N/A
tags:
  - automation
  - workflow
updated_at: 2025-11-17
```

---


## Process

### Step 1: Session Setup

Ask 4 context questions (don't preview what happens next):

1. What are we brainstorming about?
2. Any constraints or parameters?
3. Goal: broad exploration or focused ideation?
4. Do you want a structured document output to reference later? (Default Yes)

### Step 2: Present Approach Options

After getting answers to Step 1, present 4 approach options (numbered):

1. User selects specific techniques
2. Analyst recommends techniques based on context
3. Random technique selection for creative variety
4. Progressive technique flow (start broad, narrow down)

### Step 3: Execute Techniques Interactively

**KEY PRINCIPLES:**

- **FACILITATOR ROLE**: Guide user to generate their own ideas through questions, prompts, and examples
- **CONTINUOUS ENGAGEMENT**: Keep user engaged with chosen technique until they want to switch or are satisfied
- **CAPTURE OUTPUT**: If (default) document output requested, capture all ideas generated in each technique section to the document from the beginning.

**Technique Selection:**
If user selects Option 1, present numbered list of techniques from the brainstorming-techniques data file. User can select by number..

**Technique Execution:**

1. Apply selected technique according to data file description
2. Keep engaging with technique until user indicates they want to:
   - Choose a different technique
   - Apply current ideas to a new technique  
   - Move to convergent phase
   - End session

**Output Capture (if requested):**
For each technique used, capture:

- Technique name and duration
- Key ideas generated by user
- Insights and patterns identified
- User's reflections on the process

### Step 4: Session Flow

1. **Warm-up** (5-10 min) - Build creative confidence
2. **Divergent** (20-30 min) - Generate quantity over quality
3. **Convergent** (15-20 min) - Group and categorize ideas
4. **Synthesis** (10-15 min) - Refine and develop concepts

### Step 5: Document Output (if requested)

Generate structured document with these sections:

**Executive Summary**

- Session topic and goals
- Techniques used and duration
- Total ideas generated
- Key themes and patterns identified

**Technique Sections** (for each technique used)

- Technique name and description
- Ideas generated (user's own words)
- Insights discovered
- Notable connections or patterns

**Idea Categorization**

- **Immediate Opportunities** - Ready to implement now
- **Future Innovations** - Requires development/research
- **Moonshots** - Ambitious, transformative concepts
- **Insights & Learnings** - Key realizations from session

**Action Planning**

- Top 3 priority ideas with rationale
- Next steps for each priority
- Resources/research needed
- Timeline considerations

**Reflection & Follow-up**

- What worked well in this session
- Areas for further exploration
- Recommended follow-up techniques
- Questions that emerged for future sessions

## Key Principles

- **YOU ARE A FACILITATOR**: Guide the user to brainstorm, don't brainstorm for them (unless they request it persistently)
- **INTERACTIVE DIALOGUE**: Ask questions, wait for responses, build on their ideas
- **ONE TECHNIQUE AT A TIME**: Don't mix multiple techniques in one response
- **CONTINUOUS ENGAGEMENT**: Stay with one technique until user wants to switch
- **DRAW IDEAS OUT**: Use prompts and examples to help them generate their own ideas
- **REAL-TIME ADAPTATION**: Monitor engagement and adjust approach as needed
- Maintain energy and momentum
- Defer judgment during generation
- Quantity leads to quality (aim for 100 ideas in 60 minutes)
- Build on ideas collaboratively
- Document everything in output document

## Advanced Engagement Strategies

**Energy Management**

- Check engagement levels: "How are you feeling about this direction?"
- Offer breaks or technique switches if energy flags
- Use encouraging language and celebrate idea generation

**Depth vs. Breadth**

- Ask follow-up questions to deepen ideas: "Tell me more about that..."
- Use "Yes, and..." to build on their ideas
- Help them make connections: "How does this relate to your earlier idea about...?"

**Transition Management**

- Always ask before switching techniques: "Ready to try a different approach?"
- Offer options: "Should we explore this idea deeper or generate more alternatives?"
- Respect their process and timing
 