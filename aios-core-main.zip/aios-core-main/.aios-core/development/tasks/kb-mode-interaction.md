<!--
## Execution Modes

**Choose your execution mode:**

### 1. YOLO Mode - Fast, Autonomous (0-1 prompts)
- Autonomous decision making with logging
- Minimal user interaction
- **Best for:** Simple, deterministic tasks

### 2. Interactive Mode - Balanced, Educational (5-10 prompts) **[DEFAULT]**
- Explicit decision checkpoints
- Educational explanations
- **Best for:** Learning, complex decisions

### 3. Pre-Flight Planning - Comprehensive Upfront Planning
- Task analysis phase (identify all ambiguities)
- Zero ambiguity execution
- **Best for:** Ambiguous requirements, critical work

**Parameter:** `mode` (optional, default: `interactive`)

---

## Task Definition (AIOS Task Format V1.0)

```yaml
task: kbModeInteraction()
responsável: Orion (Commander)
responsavel_type: Agente
atomic_layer: Atom

**Entrada:**
- campo: task
  tipo: string
  origem: User Input
  obrigatório: true
  validação: Must be registered task

- campo: parameters
  tipo: object
  origem: User Input
  obrigatório: false
  validação: Valid task parameters

- campo: mode
  tipo: string
  origem: User Input
  obrigatório: false
  validação: yolo|interactive|pre-flight

**Saída:**
- campo: execution_result
  tipo: object
  destino: Memory
  persistido: false

- campo: logs
  tipo: array
  destino: File (.ai/logs/*)
  persistido: true

- campo: state
  tipo: object
  destino: State management
  persistido: true
```

---

## Pre-Conditions

**Purpose:** Validate prerequisites BEFORE task execution (blocking)

**Checklist:**

```yaml
pre-conditions:
  - [ ] Task is registered; required parameters provided; dependencies met
    tipo: pre-condition
    blocker: true
    validação: |
      Check task is registered; required parameters provided; dependencies met
    error_message: "Pre-condition failed: Task is registered; required parameters provided; dependencies met"
```

---

## Post-Conditions

**Purpose:** Validate execution success AFTER task completes

**Checklist:**

```yaml
post-conditions:
  - [ ] Task completed; exit code 0; expected outputs created
    tipo: post-condition
    blocker: true
    validação: |
      Verify task completed; exit code 0; expected outputs created
    error_message: "Post-condition failed: Task completed; exit code 0; expected outputs created"
```

---

## Acceptance Criteria

**Purpose:** Definitive pass/fail criteria for task completion

**Checklist:**

```yaml
acceptance-criteria:
  - [ ] Task completed as expected; side effects documented
    tipo: acceptance-criterion
    blocker: true
    validação: |
      Assert task completed as expected; side effects documented
    error_message: "Acceptance criterion not met: Task completed as expected; side effects documented"
```

---

## Tools

**External/shared resources used by this task:**

- **Tool:** task-runner
  - **Purpose:** Task execution and orchestration
  - **Source:** .aios-core/core/task-runner.js

- **Tool:** logger
  - **Purpose:** Execution logging and error tracking
  - **Source:** .aios-core/utils/logger.js

---

## Scripts

**Agent-specific code for this task:**

- **Script:** execute-task.js
  - **Purpose:** Generic task execution wrapper
  - **Language:** JavaScript
  - **Location:** .aios-core/scripts/execute-task.js

---

## Error Handling

**Strategy:** retry

**Common Errors:**

1. **Error:** Task Not Found
   - **Cause:** Specified task not registered in system
   - **Resolution:** Verify task name and registration
   - **Recovery:** List available tasks, suggest similar

2. **Error:** Invalid Parameters
   - **Cause:** Task parameters do not match expected schema
   - **Resolution:** Validate parameters against task definition
   - **Recovery:** Provide parameter template, reject execution

3. **Error:** Execution Timeout
   - **Cause:** Task exceeds maximum execution time
   - **Resolution:** Optimize task or increase timeout
   - **Recovery:** Kill task, cleanup resources, log state

---

## Performance

**Expected Metrics:**

```yaml
duration_expected: 0.5-2 min (estimated)
cost_estimated: $0.0001-0.0005
token_usage: ~500-1,000 tokens
```

**Optimization Notes:**
- Minimize external dependencies; cache results if reusable; validate inputs early

---

## Metadata

```yaml
story: N/A
version: 1.0.0
dependencies:
  - N/A
tags:
  - automation
  - workflow
updated_at: 2025-11-17
```

---

 Powered by AIOS™ Core -->

---
# No checklists needed - interactive KB mode facilitation task, no validation workflow required
---

# KB Mode Interaction Task

## Purpose

Provide a user-friendly interface to the AIOS knowledge base without overwhelming users with information upfront.

## Instructions

When entering KB mode (*kb-mode), follow these steps:

### 1. Welcome and Guide

Announce entering KB mode with a brief, friendly introduction.

### 2. Present Topic Areas

Offer a concise list of main topic areas the user might want to explore:

**What would you like to know more about?**

1. **Setup & Installation** - Getting started with AIOS
2. **Workflows** - Choosing the right workflow for your project
3. **Web vs IDE** - When to use each environment
4. **Agents** - Understanding specialized agents and their roles
5. **Documents** - PRDs, Architecture, Stories, and more
6. **Agile Process** - How AIOS implements Agile methodologies
7. **Configuration** - Customizing AIOS for your needs
8. **Best Practices** - Tips for effective AIOS usage

Or ask me about anything else related to @synkra/aios-core!

### 3. Respond Contextually

- Wait for user's specific question or topic selection
- Provide focused, relevant information from the knowledge base
- Offer to dive deeper or explore related topics
- Keep responses concise unless user asks for detailed explanations

### 4. Interactive Exploration

- After answering, suggest related topics they might find helpful
- Maintain conversational flow rather than data dumping
- Use examples when appropriate
- Reference specific documentation sections when relevant

### 5. Exit Gracefully

When user is done or wants to exit KB mode:

- Summarize key points discussed if helpful
- Remind them they can return to KB mode anytime with *kb-mode
- Suggest next steps based on what was discussed

## Example Interaction

**User**: *kb-mode

**Assistant**: I've entered KB mode and have access to the full AIOS knowledge base. I can help you with detailed information about any aspect of @synkra/aios-core.

**What would you like to know more about?**

1. **Setup & Installation** - Getting started with AIOS
2. **Workflows** - Choosing the right workflow for your project
3. **Web vs IDE** - When to use each environment
4. **Agents** - Understanding specialized agents and their roles
5. **Documents** - PRDs, Architecture, Stories, and more
6. **Agile Process** - How AIOS implements Agile methodologies
7. **Configuration** - Customizing AIOS for your needs
8. **Best Practices** - Tips for effective AIOS usage

Or ask me about anything else related to @synkra/aios-core!

**User**: Tell me about workflows

**Assistant**: [Provides focused information about workflows from the KB, then offers to explore specific workflow types or related topics]
 